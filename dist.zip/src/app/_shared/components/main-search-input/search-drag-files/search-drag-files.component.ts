import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-drag-files',
  templateUrl: './search-drag-files.component.html',
  styleUrls: ['./search-drag-files.component.scss']
})
export class SearchDragFilesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
