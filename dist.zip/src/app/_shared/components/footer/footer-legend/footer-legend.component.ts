import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-legend',
  templateUrl: './footer-legend.component.html',
  styleUrls: ['./footer-legend.component.scss']
})
export class FooterLegendComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
