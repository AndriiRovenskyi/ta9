import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-header-right',
  templateUrl: './header-right.component.html',
  styleUrls: ['./header-right.component.scss']
})
export class HeaderRightComponent implements OnInit {
  logInDropDownToggle = false;
  toolsDropDownToggle = false;

  constructor() {
  }

  ngOnInit() {
  }
}
