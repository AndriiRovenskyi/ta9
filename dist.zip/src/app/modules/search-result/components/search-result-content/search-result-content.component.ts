import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-result-content',
  templateUrl: './search-result-content.component.html',
  styleUrls: ['./search-result-content.component.scss']
})
export class SearchResultContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
