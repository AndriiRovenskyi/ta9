import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-card-drop-down',
  templateUrl: './card-drop-down.component.html',
  styleUrls: ['./card-drop-down.component.scss']
})
export class CardDropDownComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
