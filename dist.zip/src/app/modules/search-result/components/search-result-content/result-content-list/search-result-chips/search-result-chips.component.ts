import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-result-chips',
  templateUrl: './search-result-chips.component.html',
  styleUrls: ['./search-result-chips.component.scss']
})
export class SearchResultChipsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
