import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-result-content-list',
  templateUrl: './result-content-list.component.html',
  styleUrls: ['./result-content-list.component.scss']
})
export class ResultContentListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
